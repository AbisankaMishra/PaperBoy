def averages_dictionary(dict):
    averages_dict = []
    count = 0
    count_duplicate_dates = 0
    i = 0
    while (i < len(dict) - 1):
        if (dict[i]['created_at'] == dict[i+1]['created_at']):
            if (bool(averages_dict) == False):  #checking if averages dictionary is empty
                averages_dict.append({'created_at':dict[i]['created_at'], 'favorite_average': dict[i]['favorite_count'], 'retweet_average':dict[i]['retweet_count'], 'tweet:text':dict[i]['tweet:text']})
                count_duplicate_dates = 1
                print ("filled empty dictionary",averages_dict)
            else:
                averages_dict[count]['favorite_average'] = averages_dict[count]['favorite_average'] + dict[i]['favorite_count']
                averages_dict[count]['retweet_average'] = averages_dict[count]['retweet_average'] + dict[i]['retweet_count']
                count_duplicate_dates = count_duplicate_dates + 1
                print ("added")
        
        elif (dict[i]['created_at'] != dict[i+1]['created_at']):
            print ("new date now, present dictionary is", averages_dict)
            count_duplicate_dates = count_duplicate_dates + 1
            averages_dict[count]['favorite_average'] = averages_dict[count]['favorite_average']/count_duplicate_dates
            averages_dict[count]['retweet_average'] = averages_dict[count]['retweet_average']/count_duplicate_dates

            count_duplicate_dates = 0
            count = count + 1
            averages_dict.append({'created_at':dict[i+1]['created_at'], 'favorite_average':dict[i+1]['favorite_count'], 'retweet_average':dict[i+1]['retweet_count'], 'tweet:text':dict[i]['tweet:text']})

        i = i + 1

    return averages_dict



# import math

# y_axis_retweets = [1,2,3,4,5,6,7,8,9,10] #simulation for retweets #arr1
# x_axis_dates = [1,1,2,3,3,3,4,5,5,5]  #simulation for date  #arr2

# array = []
# count = 0
# averages = []

# for x in x_axis_dates:
#     if (count < len(y_axis_retweets)-1):
#         if (x != x_axis_dates[count+1]):
#             array.append(y_axis_retweets[count])
#             averages.append(sum(array)/len(array))
#             array = []
#             count = count + 1

#         elif (x == x_axis_dates[count+1]):
#             array.append(y_axis_retweets[count])
#             count = count + 1
#             if (count == len(y_axis_retweets) - 1 ):
#                 array.append(y_axis_retweets[count])
#                 averages.append(sum(array)/len(array))
#                 break

#     if (count == len(y_axis_retweets)-1):
#         array = [x_axis_dates[count]]
#         averages.append(sum(array)/(len(array)))
#         break


# print (averages)

        



# def create_average(y_axis_retweets, x_axis_dates):
#     # y_axis_retweets = [1,2,3,4,5,6,7,8,9,10] #simulation for retweets #arr1
#     # x_axis_dates = [1,1,2,3,3,3,4,5,5,5]  #simulation for date  #arr2
#     array = []
#     count = 0
#     averages = []

#     for x in x_axis_dates:
#         if (count < len(y_axis_retweets)-1):
#             if (x != x_axis_dates[count+1]):
#                 array.append(y_axis_retweets[count])
#                 averages.append(sum(array)/len(array))
#                 array = []
#                 count = count + 1

#             elif (x == x_axis_dates[count+1]):
#                 array.append(y_axis_retweets[count])
#                 count = count + 1
#                 if (count == len(y_axis_retweets) - 1 ):
#                     array.append(y_axis_retweets[count])
#                     averages.append(sum(array)/len(array))
#                     break

#         if (count == len(y_axis_retweets)-1):
#             array = [x_axis_dates[count]]
#             averages.append(sum(array)/(len(array)))
#             break
#     print (averages)
#     return averages



