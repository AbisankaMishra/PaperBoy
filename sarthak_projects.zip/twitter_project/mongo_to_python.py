import pymongo
import datetime
from sorting_dictionary import sort_dictionary

def return_tweet_data(username):
    myclient = pymongo.MongoClient("mongodb://localhost:27017")
    mydb = myclient["tweets_database"]
    mycol = mydb[username+"_tweet_data"]
    # mycol = mydb["dhh_tweet_data"]
    tweet_details_list = []

    for x in mycol.find({}, {"created_at":1, "favorite_count":1, "retweet_count":1, "tweet:text":1}):
        # x["created_at"] = x["created_at"].strftime("%d-%B")
        tweet_details_list.append(x)
    # print (tweet_details_list)
    print ("Data extracted from mongo to python")
    tweet_details_list = sort_dictionary(tweet_details_list, 'created_at')
    print ("data sorted")
    for x in tweet_details_list:
        x["created_at"] = x["created_at"].strftime("%d %B")

    return tweet_details_list
    # tweet_averages = averages_dictionary(tweet_details_list)             #shifted to another file
    # return tweet_averages

# print (return_tweet_data("narendramodi"))
    # print(tweet_details_list[0]["created_at"])

