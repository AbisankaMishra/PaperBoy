from loop import averages_dictionary
from mongo_to_python import return_tweet_data

def tweet_averaging(dict):
    tweet_averages = averages_dictionary(dict)
    return tweet_averages