from twitter_to_mongo import to_mongo
from sorting_dictionary import sort_dictionary
import pymongo
import pandas as pd

user_id_array = ['tim_cook','smritiirani','ShashiTharoor','DelhiPolice','garyvee','rajnathsingh','iamsrk','javedakhtarjadu','AmitShah','SushmaSwaraj']

for x in user_id_array:
    print ("presently querying "+x+" data")
    to_mongo(x, 100)


myclient = pymongo.MongoClient("mongodb://localhost:27017")
mydb = myclient["tweets_database"]
collection_list = mydb.list_collection_names()

print (collection_list)
dataframes = []
for x in collection_list:
    mycol = mydb[x]
    # mycol = mydb["dhh_tweet_data"]
    tweet_details_list = []
    for y in mycol.find({}, {"created_at":1, "favorite_count":1, "retweet_count":1, "tweet:text":1}):
        # x["created_at"] = x["created_at"].strftime("%d-%B")
        tweet_details_list.append(y)
        # print (tweet_details_list)
        # print ("Data extracted from mongo to python")
        tweet_details_list = sort_dictionary(tweet_details_list, 'created_at')
        # print ("data sorted")
        
    dataframe_1 = (pd.DataFrame(tweet_details_list))
    del dataframe_1['_id']
    dataframe_1.loc[:,'user_id'] = x.split('_')[0]
    dataframes.append(dataframe_1)


total_dataframe = pd.concat(dataframes)
total_dataframe.to_excel("workbook_final.xlsx")