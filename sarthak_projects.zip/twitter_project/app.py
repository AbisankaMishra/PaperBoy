from flask import Flask, render_template, request, flash, url_for, redirect
from twitter_to_mongo import to_mongo
from python_chart_save import create_chart
from mongo_to_python import return_tweet_data

app = Flask(__name__)


@app.route('/', methods=["GET","POST"])
def home():

    return render_template('home.html')

@app.route('/information', methods=["GET", "POST"])
def information():
    global tweet_details
    if request.method == "POST":
        user_id = request.form['user_id']
        tweet_count = request.form['tweet_count']
        print (user_id+" "+tweet_count)
        to_mongo(user_id,tweet_count)
        create_chart(user_id)
        tweet_details = return_tweet_data(user_id)
        image_link = "static/post.png"
        return render_template('information.html',chart_image = image_link,
        tweet1 = tweet_details[-1]['tweet:text'], tweet2 = tweet_details[-2]['tweet:text'],
        tweet3 = tweet_details[-3]['tweet:text'], tweet4 = tweet_details[-4]['tweet:text'],
        tweet5 = tweet_details[-5]['tweet:text'])

    elif request.method == "GET":
        image_link = "static/post.png"
        return render_template('information.html',chart_image = image_link,
        tweet1 = tweet_details[-1]['tweet:text'], tweet2 = tweet_details[-2]['tweet:text'],
        tweet3 = tweet_details[-3]['tweet:text'], tweet4 = tweet_details[-4]['tweet:text'],
        tweet5 = tweet_details[-5]['tweet:text'])


if __name__ == '__main__':
    app.run(debug=True)