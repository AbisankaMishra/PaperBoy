from twitter_auth import api

def return_tweet_data(username, tweet_count):
    tweets = []
    user = api.user_timeline(screen_name = username,count = tweet_count, tweet_mode = 'extended')
    for tweet in user:
        tweets.append({"id":tweet.id, 
        "created_at":tweet.created_at, 
        "favorite_count":tweet.favorite_count, 
        "retweet_count":tweet.retweet_count, 
        "tweet:text":tweet.full_text})
        
    print ("data extracted from twitter")
    return tweets
    

