import pymongo
from twitter_extraction import return_tweet_data

def to_mongo(username, tweet_count):
    myclient = pymongo.MongoClient("mongodb://localhost:27017")
    mydb = myclient["tweets_database"]
    mycol = mydb[username+"_tweet_data"]
    tweet_data = return_tweet_data(username, tweet_count)

    if (mycol.find().count() == 0):
            mycol.insert_many(tweet_data)
    else:
        print (username+" database is not empty")
    for x in tweet_data:
        print (mycol.find().count())
        if (x["created_at"] != mycol.find_one()["created_at"]):
            mycol.insert_one(x)
            print ("data transferred to mongodb")
            
        else:
            print ("data overlap")
            return username, tweet_count

    return username,tweet_count
