def sort_dictionary(dict, key):
    i = 0
    while (i < len(dict)):
        j = 0
        while (j < len(dict) - 1):
            if (dict[j][key] > dict[j+1][key]):
                temp = dict[j]
                dict[j] = dict[j+1]
                dict[j+1] = temp

            j = j + 1
        i = i + 1

    return dict


# dict = [{'id':2,'count':20}, {'id':1,'count':10}, {'id':5,'count':35}, {'id':4,'count':50}, {'id':3,'count':10}]

