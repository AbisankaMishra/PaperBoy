import matplotlib.pyplot as plt
import numpy as np
import pandas as pd 
import math
# from mongo_to_python import return_tweet_data
from tweet_average import tweet_averaging
from mongo_to_python import return_tweet_data
# from pandas.plotting import register_matplotlib_converters
# register_matplotlib_converters()
import datetime

# def create_average(y_axis_retweets, x_axis_dates):
    

def create_chart(username):
    #filling dates, retweets, and favorites lists
    y_axis_retweet_averages = []
    y_axis_favorite_averages = []
    x_axis_dates = []
    tweet_data = return_tweet_data(username)
    tweet_averages = tweet_averaging(tweet_data)
    for y in tweet_averages:
        y_axis_retweet_averages.append(y["retweet_average"])
        y_axis_favorite_averages.append(y["favorite_average"])
        x_axis_dates.append(y["created_at"])

    # print (x_axis_dates)
    # y_axis_favorites.reverse()
    # y_axis_retweets.reverse()
    # x_axis_dates.reverse()
    
    fig = plt.figure()
    plt.plot(x_axis_dates, y_axis_retweet_averages)
    plt.xlabel('Dates')
    plt.ylabel('retweets')
    plt.xticks(ticks=[0,1,2,3,4,5,6])
    fig.savefig('static/post.png')

    print ("The chart has been made")



