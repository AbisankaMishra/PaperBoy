from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
from tweepy import API
import time
import json

ckey = "afNrl71iiDUAorAvpZtoN3jG3"
csecret = "S2WSObq8fMw2LmPbtA3mOwziFf4xndAJ4gcgiSmm58cNTYRav3"
atoken = "2450047020-BJgfbDyOSMNxuU4I8eRTlPmF6u0Ap9F668hVqeA"
asecret = "0O1wK5EHEV5zYuf5epapIQAblyAkz8Thf68O6RiXKtgbe"
auth = OAuthHandler(ckey,csecret)
auth.set_access_token(atoken,asecret)
api = API(auth)






'''
f = open("logga.txt","w",encoding='utf-8')
class listener(StreamListener):
    def on_data(self,data):
        f = open("logga.txt","a",encoding='utf-8')
        all_data = json.loads(data)
        tweet = all_data["text"]
        username = all_data["user"]["screen_name"]
        f.write("{},{}".format(username,tweet))
        print (username)
        f.close()
        return True

    def on_error(self, status):
        print (status)
        f.close()

auth = OAuthHandler(ckey,csecret)
auth.set_access_token(atoken,asecret)
twitterStream = Stream(auth, listener())
twitterStream.filter(track=["dogs"]) 
'''