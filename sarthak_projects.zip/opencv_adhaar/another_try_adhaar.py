# -*- coding: utf-8 -*-
"""
Created on Sat Jul  6 11:33:43 2019

@author: Sarthak Agarwal
"""

from imutils import paths
import numpy as np
import argparse
import imutils
import cv2


# construct the argument parse and parse the arguments
#ap = argparse.ArgumentParser()
#ap.add_argument("-i", "--images", required=True, help="path to images directory")
#args = vars(ap.parse_args())

#initialize a rectangular and square structuring kernel
#later use when applying morphological operations, specifically closing
rectKernel = cv2.getStructuringElement(cv2.MORPH_RECT, (13,5))
sqKernel = cv2.getStructuringElement(cv2.MORPH_RECT, (21, 21))

imagePath = 'data_adhaar_input/sarthak_adhaar.jpeg'
#load image, resize, and convert to grayscale
image = cv2.imread(imagePath)
image = imutils.resize(image, height = 600)
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

#smooth image using 3x3 gaussian, apply blackhat
#morphological operator to find dark regions on a light background

gray = cv2.GaussianBlur(gray, (3,3), 0)
blackhat = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, rectKernel)

#a blackhat operator is used to reveal dark regions against light
#backgrounds. since adhaar number text is always black on a light bg,
#a blackhat operation is appropriate

# compute the Scharr gradient of the blackhat image and scale the
# result into the range [0, 255]
#gradX = cv2.Sobel(blackhat, ddepth=cv2.CV_32F, dx=1, dy=0, ksize=-1)
#gradX = np.absolute(gradX)
#(minVal, maxVal) = (np.min(gradX), np.max(gradX))
#gradX = (255 * ((gradX - minVal) / (maxVal - minVal))).astype("uint8")

#now, we will try to detect actual lines of MRZ
#apply a closing operation using rectangular kernel to close
#gaps in between letters -- then apply Otsu's thresholding method
gradX = cv2.morphologyEx(blackhat, cv2.MORPH_CLOSE, rectKernel) #gradX
thresh = cv2.threshold(gradX, 0, 255, cv2.THRESH_OTSU)[1]

#perform another closing operation, this time using the square
#kernel to close gaps between lines of the MRZ, then perform a
#series of erosions to break apart connected components
thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, sqKernel)
thresh = cv2.erode(thresh, None, iterations= 1)

#during thresholding, its possible border pixel were
#included in thresholding, so lets set top, bottom, left and right zero acoording to ratios

print (image.shape)
col_right = int(image.shape[1]*0.3)
col_left = int(image.shape[1]*0.3)
row_top = int(image.shape[0]*0.63)
row_bot = int(image.shape[0]*0.12)
thresh[:, 0:col_left] = 0    #this removes from the left columns
thresh[:, image.shape[1] - col_right:] = 0  #this removes from right after subtracting
thresh[0:row_top, :] = 0  #this removes from top row
thresh[image.shape[0] - row_bot:, :] = 0  #this removes from bottom row

#find contours in the thresholded image
items = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
#cnts = items[0] if len(items) == 2 else items[1]
print (len(items))
if (len(items) == 2):
    (x1,y1,w1,h1) = cv2.boundingRect(items[0])
    (x2,y2,w2,h2) = cv2.boundingRect(items[1])
    cv2.rectangle(image, (x1, y1), (x1 + w1, y1 + h1), (0, 255, 0), -1)
    cv2.rectangle(image, (x2, y2), (x2 + w2, y2 + h2), (0, 255, 0), -1)
    #cv2.drawContours(image, items, -1, (0,255,0), 3)

elif (len(items) == 1):
    (x1,y1,w1,h1) = cv2.boundingRect(items[0])
    cv2.rectangle(image, (x1, y1), (x1 + w1, y1 + h1), (0, 255, 0), -1)
    #cv2.drawContours(image, items, -1, (0,255,0), 3)
    
    
cv2.imshow("image", image)   
cv2.imshow("thresh", thresh) 
cv2.waitKey(0)
cv2.destroyAllWindows()