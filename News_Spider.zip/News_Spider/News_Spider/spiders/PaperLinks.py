NewsLinks = [
    "https://www.thehindu.com",
    "https://www.divyahimachal.com/",
    "https://www.bhaskar.com/",
    "https://timesofindia.indiatimes.com/city/shimla",
    "https://timesofindia.indiatimes.com/india/himachal-pradesh",
    "https://www.hindustantimes.com/",
    "https://himachalabhiabhi.com/",
    "https://thenewshimachal.com/"
]


